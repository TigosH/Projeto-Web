<html>
<body>
    <head>
        <title> Locais de Pesca que Recomendamos </title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
    <li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./aboutus.php">Sobre Nós</a></li>
	</ul>
    <br><br>
		
		<main>

        <h1><p class=" center cambria50">Barragem de Magos</p></h1>

        <div>
				<p class="margin center cambria24">A Barragem de Magos recebe todos os anos diversas  competições oficiais da Federação Portuguesa de Pesca Desportiva, na modalidade de feeder.
                                                É uma barragem de tamanho médio em que é possivel capturar algumas espécies de peixes interessantes.
                </p>
		</div>

            <div class="contentor">
			<div class="conteudo">
            <h1><p class="cambria24 "> Localização da Barragem </p> </h1>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7137.904315245635!2d-8.685493073257984!3d38.99165468270784!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd191d5e657d80f3%3A0xe6d307602662bca0!2sBarragem%20de%20Magos!5e1!3m2!1spt-PT!2spt!4v1673976810354!5m2!1spt-PT!2spt" width="450" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                          
            </div>

            <div class="conteudo">
            <h1><p class="cambria24 "> &nbsp; </p> </h1>
                    <table  border="1">
                        <colgroup>
                        <col span="3" class="white">
                    <thead>
                    <tr>
                        <th>Éspecies Existentes</th>
                        <th>Tipos de Pesca Que Pode Realizar </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Carpa</td>
                        <td>CarpFishing</td>
                    </tr>
                    <tr>
                        <td>Pimpão</td>
                        <td>Pesca á Boia</td>
                    </tr>
            
                    </tbody>
                    </table>    
            </div>  
            </div>  

            <br><br>
            
		</main>

</body>
</html>