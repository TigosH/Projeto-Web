<html>
<body>
    <head>
        <title> Locais de Pesca que Recomendamos </title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
    <li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
	</ul>
    <br><br>
	
	<div class="column">
    <h1><p class=" cambria24 "> Carpa </p> </h1>
    <img class="contorno" src="imagens/carpa.jpg" width="350" height="168"> 
	<br><br>
	</div>
	
	<div class="column">
	<h1><p class="cambria24 "> Achigã </p> </h1>
    <img class="contorno" src="imagens/achiga.jpg" width="350" height="168">  
	<br><br>
	</div>
	
	<div class="column">
	<h1><p class="cambria24 "> Barbo </p> </h1>
    <img class="contorno" src="imagens/barbo.jpg" width="350" height="168">    
	<br><br>
	</div>
	
	<div class="column">
	<h1><p class="cambria24"> Lucioperca </p> </h1>
	<img class="contorno" src="imagens/lucioperca.jpg" width="350" height="168">  
	<br><br>
	</div>
	
	<div class="column">
	<h1><p class="cambria24"> Lúcio Real </p> </h1>
	<img class="contorno" src="imagens/lucio.jpg" width="350" height="168"> 
	<br><br>
	</div>
	
	<div class="column">
	<h1><p class="cambria24"> Pimpão </p> </h1>
	<img class="contorno" src="imagens/pimpao.jpg" width="350" height="168"> 
	<br><br>
	</div>
	
	
</body>
</html>