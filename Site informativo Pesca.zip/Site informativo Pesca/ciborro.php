<html>
<body>
    <head>
        <title> Locais de Pesca que Recomendamos </title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
    <li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
	</ul>
    <br><br>
		
		<main>

        <h1><p class=" center cambria50">Barragem do Ciborro (Tabueira)</p></h1>

        <div>
				<p class="margin center cambria24">A Barragem do Ciborro (Tabueira) é uma barragem muito agradável para passar um fim de semana e praticar
                    a pesca desportiva pois nesta barragem vivem centenas de exemplares (peixes) de grande tamanho.Nesta barragem existe também uma escola de Ski onde se pode praticar desportos náuticos</p>
                
		</div>

        <div class="contentor">
			<div class="conteudo">
            <h1><p class="cambria24 "> Localização da Barragem </p> </h1>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10122.515603140611!2d-8.21871077316179!3d38.79495998863626!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd19b95c4217eb87%3A0x51c2dae0b83c0105!2sBarragem%20de%20Tabueira!5e1!3m2!1spt-PT!2spt!4v1673976976322!5m2!1spt-PT!2spt" width="450" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                          
            </div>

            <div class="conteudo">
            <h1><p class="cambria24 "> &nbsp; </p> </h1>
                    <table  border="1">
                        <colgroup>
                        <col span="3" class="white">
                    <thead>
                    <tr>
                        <th>Éspecies Existentes</th>
                        <th>Tipos de Pesca Que Pode Realizar </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Carpa</td>
                        <td>CarpFishing</td>
                    </tr>
                    <tr>
                        <td>Achigã</td>
                        <td>Pesca de Predadores (Com amostras)</td>
                    </tr>
                    <tr>
                        <td>Barbo</td>
                        <td>Pesca á Boia</td>
                    </tr>
                    </tbody>
                    <tfoot>
                        <td>Peixe Gato</td>
                        <td>Pesca ao Feeder</td>
                    </tfoot>
                    </table>    
            </div> 
        </div> 

            <br><br>
            
		</main>

</body>
</html>