<html>
<body>

    <head>
	    <title> Pesca & Companhia </title>
		<link rel="stylesheet" href="style.css" />             
    </head>

    

	<div class="Header">
		<h1>Pesca e Companhia</h1>
	</div>

	<ul>
		<li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
	</ul>
	<br><br>
		
		<main>

			<div>
				<p class="center cambria24">Pesca e Companhia o website onde podes ver algumas Capturas, 
                    entender melhor a arte da pesca despostiva e melhorares com as nossas dicas para obteres mais capturas</p>
			</div>
		</main>
		
		
</body>
</html>