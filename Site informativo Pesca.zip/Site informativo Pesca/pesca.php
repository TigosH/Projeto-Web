<html>
<body>

    <head>
	    <title> Pesca & Companhia </title>
		<link rel="stylesheet" href="style.css" />             
    </head>

    

	<div class="Header">
		<h1>Pesca & Companhia</h1>
	</div>

	<ul>
		<li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./aboutus.php">Sobre Nós</a></li>
	</ul>
	<br><br>
		
		<main>

			<div>
				<p class="margin center cambria24">Pesca & Companhia é um website onde podes conhecer alguns dos locais mais famosos 
					para a pesca desportiva , obteres mais informações sobre esses mesmos locais e até aprenderes técnicas diferentes de pesca!
				</p>
			</div>

			<br>

			<div class=" center ">
			<h1><p class=" center cambria24"> Dica do Desenvolvedor </p></h1>
			<iframe width="700" height="400" src="https://www.youtube.com/embed/_qTy_E9o6aQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
			</div>

		</main>

		<br><br>

		
</body>
</html>