<?php
	session_start();
	
	$_SESSION["username"] = $_GET["username"];
	
	if ($_GET["password"] == "1234") {
		header('Location: pesca.php');
	} else {
		session_unset();
		session_destroy();
		header('Location: login.html');
	}

	if ($_GET["password"] == "antonio") {
		header('Location: pesca.php');
	} else {
		session_unset();
		session_destroy();
		header('Location: login.html');
	}

?>