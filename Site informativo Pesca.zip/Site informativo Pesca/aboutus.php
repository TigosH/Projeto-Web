<html>
<body>
    <head>
        <title> Sobre Nós </title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
    <li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./aboutus.php">Sobre Nós</a></li>
	</ul>
    <br><br>
	
	
    <div class="row">
        <div class="column">
            <div class="card">
                <img class="contorno"  src="imagens/tiago.jpg" style="width:80%">
                <div class="container">
                    <h2> <p class="cambria24"> Tiago Alves </h2>
                    <p>Email: tigos.a.02@gmail.com</p>
					<A href="https://www.instagram.com/tiago__alves553/"><img src="imagens/instalogo.png" style="width:15%"></img></A>
                </div>
			</div>
		</div>

        <div class="column">
            <div class=" card">
                <img class="centerg contorno" src="imagens/logo.png" style="width:80%">
                <p>Curso: Tecnologias e Programação de Sistemas de Informação</p>
                <div class="container">
                </div>
            </div>
        </div>
		

        <div class="column">
            <div class="card">
                <img class="contorno"  src="imagens/edu.jpg" style="width:80%">
                <div class="container">
                    <h2> <p class="cambria24"> Eduardo Ribeiro</h2>
                    <p>Email: eduardo_ribeiro2003@hotmail.com</p>
					<A href="https://www.instagram.com/eduardoribeiro4375/"><img src="imagens/instalogo.png" style="width:15%"></img>
                </div>
            </div>
        </div>
    </div>

</body>
</html>