<html>
<body>
    <head>
        <title> Locais de Pesca que Recomendamos </title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
    <li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./aboutus.php">Sobre Nós</a></li>
	</ul>
    <br><br>
	
	<div class="column">
    <h1><p class="cambria24 "> Barragem de Montargil </p> </h1>
    <img class="contorno" src="imagens/montargil.jpg" width="350" height="168"> 
	<br><br>
	<button class="button" type="button" onclick="location.href='./montargil.php'" class='hidden' >
            <a> Saber Mais </a>
    </button>   

	</div>
	
	<div class="column">
	<h1><p class="cambria24 "> Barragem de Fronteira </p> </h1>
    <img class="contorno" src="imagens/fronteira.jpg" width="350" height="168">  
	<br><br>
	<button class="button" type="button" onclick="location.href='./fronteira.php'" class='hidden' >
            <a> Saber Mais </a>
    </button>  

	</div>
	
	<div class="column">
	<h1><p class="cambria24 "> Barragem de Alpiarça </p> </h1>
    <img class="contorno" src="imagens/alpiarça.jpg" width="350" height="168">    
	<br><br>
	<button class="button" type="button" onclick="location.href='./alpiarca.php'" class='hidden' >
            <a> Saber Mais </a>
    </button> > 

	</div>
	
	<div class="column">
	<h1><p class="cambria24"> Barragem do Alqueva </p> </h1>
	<img class="contorno" src="imagens/alqueva.jpg" width="350" height="168">  
	<br><br>
	<button class="button" type="button" onclick="location.href='./alqueva.php'" class='hidden' >
            <a> Saber Mais </a>
    </button>  
    
	</div>
	
	<div class="column">
	<h1><p class="cambria24"> Barragem de Magos </p> </h1>
	<img class="contorno" src="imagens/magos.jpg" width="350" height="168"> 
	<br><br>
	<button class="button" type="button" onclick="location.href='./magos.php'" class='hidden' >
            <a> Saber Mais </a>
    </button>  
    
	</div>
	
	<div class="column">
	<h1><p class="cambria24"> Barragem do Ciborro </p> </h1>
	<img class="contorno" src="imagens/ciborro.jpg" width="350" height="168"> 
	<br><br>
	<button class="button" type="button" onclick="location.href='./ciborro.php'" class='hidden' >
            <a> Saber Mais </a>
    </button> 
	
	</div>
	
	
</body>
</html>