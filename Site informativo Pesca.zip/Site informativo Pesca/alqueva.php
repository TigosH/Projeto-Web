<html>
<body>
    <head>
        <title> Locais de Pesca que Recomendamos </title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
    <li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
	</ul>
    <br><br>
		
		<main>

        <h1><p class=" center cambria50">Barragem do Alqueva</p></h1>

			<div class="centerg">
                <iframe  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d49543.17277839321!2d-8.192018518659886!3d39.096262691519364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd1835f2fd7d4a9b%3A0xc5010b6be9b6ace4!2sAlbufeira%20da%20Barragem%20de%20Montargil!5e0!3m2!1spt-PT!2spt!4v1673863200481!5m2!1spt-PT!2spt" width="400" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                          
            </div>

            <div>
                    <table  border="1">
                        <colgroup>
                        <col span="3" class="white">
                    <thead>
                    <tr>
                        <th>Éspecies Existentes</th>
                        <th>Tipos de Pesca Que Pode Realizar </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Carpa</td>
                        <td>CarpFishing</td>
                    </tr>
                    <tr>
                        <td>Achigã</td>
                        <td>Pesca de Predadores (Com amostras)</td>
                    </tr>
                    <tr>
                        <td>Barbo</td>
                        <td>Pesca á Boia</td>
                    </tr>
                    </tbody>
                    <tfoot>
                        <td>Peixe Gato</td>
                        <td>Pesca ao Feeder</td>
                    </tfoot>
                    </table>    
            </div>  

            <br><br>
            
		</main>

</body>
</html>