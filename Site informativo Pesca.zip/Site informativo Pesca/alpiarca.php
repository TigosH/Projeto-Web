<html>
<body>
    <head>
        <title> Locais de Pesca que Recomendamos </title>
        <link rel="stylesheet" href="style.css" />
    </head>

    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
    <li><a href="./pesca.php"> Página Inicial </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./especies.php">Espécies Mais Famosas em Portugal</a></li>
		<li><a href="./aboutus.php">Sobre Nós</a></li>
	</ul>
    <br><br>
		
		<main>

        <h1><p class=" center cambria50">Barragem de Alpiarça (Patudos)</p></h1>

        <div>
				<p class="margin center cambria24">A barragem de Alpiarça ou Albufeira dos Patudos, proporciona óptimas condições para a prática da pesca desportiva.
                                                Recebe, regularmente concursos de pesca de nível competitivo e de lazer.</p>
		</div>

        <div class="contentor">
			<div class="conteudo">
            <h1><p class="cambria24 "> Localização da Barragem </p> </h1>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2514.5332122702343!2d-8.586774947149555!3d39.24608568045758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x69d835ed19845244!2sAlbufeira%20dos%20Patudos!5e1!3m2!1spt-PT!2spt!4v1673976607060!5m2!1spt-PT!2spt" width="450" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                          
            </div>

            <div class="conteudo">
            <h1><p class="cambria24 "> &nbsp; </p> </h1>   
                    <table  border="1">
                        <colgroup>
                        <col span="3" class="white">
                    <thead>
                    <tr>
                        <th>Éspecies Existentes</th>
                        <th>Tipos de Pesca Que Pode Realizar </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Carpa</td>
                        <td>CarpFishing</td>
                    </tr>
                    <tr>
                        <td>Barbo</td>
                        <td>Pesca ao Feeder</td>
                    </tr>
                    </tbody>
                    <tfoot>
                        <td>Pimpão</td>
                        <td>Pesca á Boia</td>
                    </tfoot>
                    </table>    
            </div>  
        </div>  

            <br><br>
            
		</main>

</body>
</html>