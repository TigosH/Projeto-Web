<html>
<body>
    <head>
        <title> Capturas de peixes </title>
        <link rel="stylesheet" href="style.css" />  
    </head>
    
    <div class="Header">
        <h1>Pesca & Companhia</h1>
    </div>
	
    <ul>
		<li><a href="./pesca.php"> Apresentação </a></li>
		<li><a href="./galeria.php"> Algumas Capturas </a></li>
		<li><a href="./locais.php"> Locais Recomendados para pesca </a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
		<li><a href="./">-------</a></li>
	</ul>
    
    <br><br>
    <br><br>


    <h1><p class=" center cambria50">Capturas de alguns exemplares em diferentes locais</p></h1>
    <br><br>



    <div class="slideshow-container">

        <div class="mySlides fade">
            <div class="numbertext">1 / 7</div>
            <img src="imagens/imagem1.jpg" style="width:100%">
            <div class="text ">Espécie: Achigã 
                        <br>   Local da Captura: Barragem de Ulme
            </div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">2 / 7</div>
            <img src="imagens/imagem2.jpg" style="width:100%">
            <div class="text">Espécie: Carpa
                        <br>   Local da Captura: Barragem de Fronteira
            </div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">3 / 7</div>
            <img src="imagens/imagem3.jpg" style="width:100%">
            <div class="text">Espécie: Carpa
                            <br>   Local da Captura: Barragem de Fronteira
            </div>
        </div>
		
		<div class="mySlides fade">
            <div class="numbertext">4 / 7</div>
            <img src="imagens/imagem4.jpg" style="width:100%">
            <div class="text">Espécie: Carpa
                            <br>   Local da Captura: Barragem de Fronteira
            </div>
        </div>
		
		<div class="mySlides fade">
            <div class="numbertext">5 / 7</div>
            <img src="imagens/imagem5.jpg" style="width:100%">
            <div class="text">Espécie: Barbo
                        <br>   Local da Captura: Barragem de Alpiarça
            </div>
        </div>
		
		<div class="mySlides fade">
            <div class="numbertext">6 / 7</div>
            <img src="imagens/imagem6.jpg" style="width:100%">
            <div class="text">Espécie: Carpa
                        <br>   Local da Captura: Barragem de Fronteira
            </div>
        </div>
		
		<div class="mySlides fade">
            <div class="numbertext">7 / 7</div>
            <img src="imagens/imagem7.jpg" style="width:100%">
            <div class="text">Espécie: Achigã 
                         <br>   Local da Captura: Barragem dos Canteirinhos
            </div>
        </div>

        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>

    </div>
    <br>

    <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
		<span class="dot" onclick="currentSlide(4)"></span>
		<span class="dot" onclick="currentSlide(5)"></span>
		<span class="dot" onclick="currentSlide(6)"></span>
		<span class="dot" onclick="currentSlide(7)"></span>
		
    </div>
     
    <script>
        var slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            var i;
            var slides = document.getElementsByClassName("mySlides");
            var dots = document.getElementsByClassName("dot");
            if (n > slides.length) { slideIndex = 1 }
            if (n < 1) { slideIndex = slides.length }
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
        }
    </script>
    

</body>
</html>